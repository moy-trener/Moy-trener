import React from 'react'

export default function App() {
  return (
    <div>
      <h1>Привет от Мой Тренер!</h1>
      <p>Это стартовое приложение.</p>
    </div>
  )
}